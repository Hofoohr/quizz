# Sorts de l'Eniripsa

## Mot Espiègle (id 25877)
Occasionne des dommages Air et retire des PM.

## Mot Tapageur (id 25858)
Soigne les alliés et occasionne des dommages Feu aux ennemis en zone.

## Mot Vampirique (id 25870)
Vole de la vie dans l'élément Eau aux ennemis ou transfère une partie de la vie du lanceur à l'allié ciblé.

## Juron (id 25867)
Occasionne des dommages Terre aux ennemis et repousse la cible.

## Mot d'Amitié (id 25795)
Invoque un Lapino maîtrisable qui peut soigner ou appliquer un bouclier.
Il peut également se transformer s'il est dans l'état Contrôlé pour occasionner des dommages dans l'élément de l'{{spell,25930,1::Alchi-Rhétorique}}.

Le Lapino est téléporté et immobilisé sur la case ciblée si le sort est relancé quand il est en vie.

À sa mort, le lanceur pose un glyphe sous le Lapino qui occasionne des dommages aux ennemis ou soigne les alliés dans le meilleur élément du lanceur et le temps de relance du sort est fixé à 2 tours.

## Mot Stimulant (id 25742)
Augmente les PA de l'allié ciblé et lui applique l'état Encouragé.
Le cumul est partagé entre les Encouragements.

Sur une case libre : invoque une Fée Stimulante.

## Mot de Frayeur (id 13175)
Repousse la cible.

## Lamentations (id 25871)
Vole de la vie dans l'élément Eau aux ennemis et soigne les alliés selon les dommages occasionnés en zone.
N'affecte pas le lanceur.

## Mot Turbulent (id 25860)
Soigne les alliés, occasionne des dommages Feu aux ennemis et leur applique l'état Turbulent en zone :
• Repousse les entités au contact de la cible à la fin de son tour.

## Mot Vivifiant (id 25744)
Augmente les PM et la Fuite de l'allié ciblé et lui applique l'état Encouragé.
Le cumul est partagé entre les Encouragements.

Sur une case libre : invoque une Fée Vivifiante.

## Mot Farceur (id 25879)
Occasionne des dommages Air aux ennemis ou soigne les alliés et applique l'état Farce sur la cible :
• Téléporte la cible à sa position précédente à la fin de son tour.

## Peinture de Guerre (id 25868)
Peint la cible et occasionne des dommages Terre aux ennemis ou soigne les alliés.

<b>État Peinture :</b>
• Sur un ennemi : réduit ses Résistances Poussée.
• Sur un allié : soigne au début de son tour.

## Mot de Jouvence (id 25743)
Réduit la durée des effets sur l'allié ciblé, le soigne immédiatement et en début de tour et lui applique l'état Encouragé.
Le cumul est partagé entre les Encouragements.

Sur une case libre : invoque une Fée de Jouvence.

## Cri de Guerre (id 25863)
Occasionne des dommages Terre aux ennemis et repousse les cibles en zone.
Les dommages de zone ne sont pas dégressifs.

## Mot Interdit (id 25873)
Réduit la durée des effets sur la cible, occasionne des dommages Eau aux ennemis ou soigne les alliés.

## Mot Accablant (id 25749)
Retire des PM et de l'Esquive PM à l'ennemi ciblé et lui applique l'état Moqué.
Le cumul est partagé entre les Moqueries.

Sur une case libre : invoque un Feu Accablant.

## Chapardage (id 25859)
Vole de la Portée à la cible et de la vie dans l'élément Feu aux ennemis.

## Mot Fleuri (id 25880)
Occasionne des dommages Air aux ennemis et applique l'état Floraison sur les cibles en zone :
• Soigne les alliés en zone autour de la cible à la fin de son tour.

## Mot d'Envol (id 13184)
Échange de position avec l'allié ciblé.

## Pinceau Tribal (id 25866)
Peint la cible et soigne les alliés ou occasionne des dommages Terre aux ennemis.

Sur une cible Peinte : propage la Peinture, soigne les alliés et occasionne des dommages Terre aux ennemis en zone.

Sur le lanceur : consomme toutes les Peintures pour occasionner des dommages Terre à tous les ennemis Peints.
• Les dommages sont augmentés pour chaque ennemi touché avant d'appliquer les effets.
• Augmente les Dommages Poussée du lanceur pour chaque allié touché.

## Cryothérapie (id 25875)
Occasionne des dommages Eau aux ennemis et applique l'état Cryothérapie sur la cible :
• Applique un bouclier sur l'allié ciblé ou retire de la Fuite aux ennemis.
• Retire les effets du sort pour soigner les alliés et occasionner des dommages Eau aux ennemis en zone si la cible perd l'état.

## Mot de Reconstitution (id 13187)
Soigne totalement l'allié ciblé mais le rend Insoignable.

